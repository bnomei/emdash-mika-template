// mika-template-version: 0.2.0
/**
 * Host backend API module for the Astro storefront template.
 * Replace the empty overrides with `createMikaBackendApi({ ... })` wired to host repositories,
 * providers, and notifications — see examples/backend-provider.md. Left unedited, plugin
 * construction fails loudly (assertWired) instead of answering 501 on every route.
 */
import type { MikaApiOverrides } from "@bnomei/emdash-mika/server";
import { createMikaBackendApi, type MikaBackendDependencies } from "@bnomei/emdash-mika/server";
import { createMikaStorefront, type MikaStorefrontOptions } from "@bnomei/emdash-mika/storefront";

/** Compose both server surfaces from the SAME durable host dependencies. No storage is created. */
export function createMikaHost(
  backend: MikaBackendDependencies & {
    readonly repositories: MikaStorefrontOptions["repositories"];
  },
) {
  const api = createMikaBackendApi(backend);
  const storefrontOptions = {
    api,
    backend,
    repositories: backend.repositories,
    hash: backend.hash,
    now: backend.now,
    accountTools: { enabled: false },
  } satisfies MikaStorefrontOptions;
  return { api, storefrontOptions, storefront: createMikaStorefront(storefrontOptions) };
}

/** Host-owned Mika backend implementation consumed by the plugin entrypoint and actions. */
export const api: MikaApiOverrides = {};
/** Replace these scaffold exports with createMikaHost(hostBackend); see astro-storefront.md. */
export const storefrontOptions: MikaStorefrontOptions | undefined = undefined;
