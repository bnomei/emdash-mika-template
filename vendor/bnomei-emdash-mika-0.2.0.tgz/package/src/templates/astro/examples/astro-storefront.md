# Astro Storefront Example

This is the default copy path for an agent-ready Astro storefront that uses
EmDash content for products and Mika for commerce state.

The point of the example is a working content-led storefront: visible product
pages, stock-aware purchase forms, cart and checkout handoff, account/download
flows, provider webhooks, and public agent-readable metadata that all describe
the same commerce state.

## 1. Register Mika

Copy `lib/mika-api.ts` and `lib/mika-plugin.ts`, then register the entrypoint
that merges the host-owned API implementation behind the EmDash descriptor's
JSON boundary:

```ts
// astro.config.mjs
import { fileURLToPath } from "node:url";
import { defineConfig } from "astro/config";
import { emdash } from "emdash/astro";
import { mikaPlugin } from "@bnomei/emdash-mika";
import { mikaAccountExportIntegration } from "@bnomei/emdash-mika/astro";

export default defineConfig({
  integrations: [
    mikaAccountExportIntegration({
      entrypoint: fileURLToPath(new URL("./src/lib/mika-api.ts", import.meta.url)),
    }),
    emdash({
      plugins: [
        mikaPlugin({
          entrypoint: fileURLToPath(new URL("./src/lib/mika-plugin.ts", import.meta.url)),
        }),
      ],
    }),
  ],
});
```

`api` (merged in `src/lib/mika-plugin.ts`) can be composed with
`createMikaBackendApi()` or supplied as explicit method overrides. See
[backend and provider wiring](./backend-provider.md).

The package-owned export integration injects an exact Astro HTTP endpoint at the
existing `/_emdash/api/plugins/mika/account/export/download` URL. This is required
with EmDash 0.22, whose plugin dispatch JSON-wraps returned `Response` objects.
The server-only entrypoint exports the same live `api` as the plugin and may
export `operationPolicy` and `onError`; share the policy when the plugin uses one.
Astro's real session and locale pass through unchanged. Token GET renders a
non-consuming confirmation; same-origin browser POST serves the built-in JSON
artifact as an attachment. API DTOs contain only metadata, never inline bytes.
Do not copy or customize the package-owned endpoint, or install a competing
route at that exact path. Host middleware must allow this public token route
and initialize the same session used by account Actions. An SSR adapter is
required for production; custom external artifact delivery remains host-owned.

## 2. Copy Actions

Copy the template action files into the host project:

```txt
src/actions/index.ts
src/actions/mika.ts
```

The default action module is intentionally small:

```ts
import { createMikaActions } from "./mika";
import { api } from "../lib/mika-api";

export const server = {
  mika: createMikaActions({ api }),
};
```

Add host policy with the `guard` option:

```ts
import { ActionError } from "astro:actions";
import { createMikaActions } from "./mika";
import { api } from "../lib/mika-api";

export const server = {
  mika: createMikaActions({
    api,
    guard: async (ctx, action, input) => {
      const limited = false;

      if (limited) {
        throw new ActionError({
          code: "TOO_MANY_REQUESTS",
          message: "Please try again later.",
        });
      }
    },
  }),
};
```

Use the guard for rate limits, account checks, bot checks, and temporary feature
locks. Keep Astro's `security.checkOrigin` enabled for browser-form CSRF
baseline protection.

### Opt in to WebMCP and/or annotations

Copy `components/MikaStorefront.astro` alongside `MikaKumoPage.astro`. The
copied `lib/mika-api.ts` scaffold deliberately has no production backend and
does not register storefront Actions until wired. Keep its `createMikaHost`
function and replace the two scaffold exports with the following composition:

```ts
// src/lib/mika-api.ts — keep the copied createMikaHost function above this.
import { createMikaProviderRegistry } from "@bnomei/emdash-mika/provider";
import { createCurrencyCode, createMikaId, createProviderName } from "@bnomei/emdash-mika/types";
import { repositories } from "./mika-repositories";
import { stripeProvider } from "./providers/stripe";
import { handleMikaNotification } from "./mika-notifications";

export const backend = {
  repositories,
  providers: createMikaProviderRegistry([stripeProvider]),
  notifications: { handle: handleMikaNotification },
  defaults: { currency: createCurrencyCode("EUR"), provider: createProviderName("stripe") },
  config: { checkout: { successUrl: "/checkout/success", cancelUrl: "/checkout/cancel" } },
  createId: (namespace: string) => createMikaId(`${namespace}_${crypto.randomUUID()}`),
  now: () => new Date(),
  hash: async (input: string | Uint8Array) => {
    const bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  },
} satisfies MikaBackendDependencies;

export const { api, storefrontOptions, storefront } = createMikaHost(backend);
```

The three imported host modules are **required implementations**, not files
Mika creates: durable catalog/session/account/ledger/ops/stock/ephemeral
repositories, a real configured provider, and notification delivery. Follow
[backend-provider.md](./backend-provider.md), including migrations, provider
credentials and maintenance. Do not copy the WebMCP test fixture's memory
collections, fake provider, seeded accounts, or fixed clock into production.
The ops adapter must additionally implement `findStorefrontRun` and
`updateStorefrontRun` for durable tool-run/recovery storage, and catalog must
implement `listItems` and `findPriceById`. The package repository classes used
by the fixture provide these methods; custom host ports must provide them too.
Actions and page module graphs must reach the same durable database; separate
in-memory instances are not a production integration.

`createMikaHost` supplies `createMikaStorefront` and the options for its Astro
Actions using the **same backend** as ordinary forms. Keeping `backend` is
essential for mutation-boundary review checks, not just catalog reads.
Register the complete Action map (the copied `actions/index.ts` also does this
conditionally when `storefrontOptions` is supplied):

```ts
// src/actions/index.ts
import { createMikaActions } from "./mika";
import { createMikaStorefrontActions } from "@bnomei/emdash-mika/storefront-actions";
import { api, storefrontOptions } from "../lib/mika-api";

export const server = {
  mika: createMikaActions({ api }),
  mikaStorefront: createMikaStorefrontActions(storefrontOptions),
};
```

Use a server session driver shared across requests/instances for identity,
opaque pagination cursors, and pending human reviews. Keep same-origin checks;
add rate limits/authorization via each factory's `guard` and optionally
`humanConfirmation` on storefront Actions. `confirm` belongs only to the
visible human review button, never to an agent tool. Account tools default to
disabled; enable `accountTools: { enabled: true }` only after wiring auth,
notifications and account policy. Customize `contentUrl` and optional paginated
`search` in the host's storefront options to match actual EmDash routes/content.

```astro
<MikaKumoPage title="Product" storefront>
  <ProductPurchase sellables={sellables} />
</MikaKumoPage>
<!-- Independent alternatives: annotations need no commerce Actions. -->
<!-- <MikaKumoPage title="Product" annotations webmcp={false}>...</MikaKumoPage> -->
<!-- <MikaKumoPage title="Product" webmcp annotations={false}>...</MikaKumoPage> -->
```

Page defaults remain off until explicitly opted in. `storefront` enables both;
explicit `webmcp` and `annotations` override it independently. Directly placing
`<MikaStorefront />` opts in to both; its `enabled={false}` disables both.
Browsers lacking `document.modelContext` or annotation support retain ordinary
HTML forms, and all forms remain native when JavaScript is disabled. The
component delegates to `mountMikaStorefrontUI`, which enhances same-origin Mika
cart/wishlist POST forms inside authoritative views; checkout and authentication
keep native navigation. Form responses and tool mutations refresh uniquely
keyed `data-mika-storefront-view` SSR regions and cart badges, then refresh
enabled annotations and tools. Custom layouts must mark authoritative regions
too. Unrelated dirty human controls retain their drafts across refreshes;
successfully submitted controls and hidden server-authoritative fields use the
fresh SSR values. WebMCP and annotations can be enabled independently; an
annotation-only mount needs no storefront transport. Keep product content and
cart/account pages request-rendered and uncached.

### Breaking Action envelope handling

Ordinary `actions.mika.*` now preserve the Mika result **inside** Astro's safe
Action result. Check both layers; old code reading `result.data.redirectUrl`
or assuming a truthy `result.data` means success is incorrect:

```ts
const result = Astro.getActionResult(actions.mika.checkout.start);
if (result?.error) {
  // Astro validation/guard error: result.error.code and result.error.message.
} else if (result?.data?.ok === false) {
  // Commerce failure: result.data.error.code and result.data.error.message.
} else if (result?.data?.ok && result.data.data.redirectUrl) {
  return Astro.redirect(result.data.data.redirectUrl);
}
```

Branch on stable error codes, not message text. The same nested envelope applies
to browser Action calls. `mikaStorefront.describe/invoke/confirm` instead return
tool descriptions or a `MikaStorefrontResponse` inside Astro's envelope, not a
Mika `ok/data` result; the copied component unwraps only Astro's layer and the
WebMCP runtime handles response statuses and review/handoff states.

## 3. Copy Core Storefront Components

For a product-first storefront, start with:

```txt
styles/kumo.css
lib/display.ts
lib/routes.ts
components/MikaKumoAppFrame.tsx
components/MikaKumoPage.astro
components/ProductPurchase.astro
components/ProductPurchaseSync.astro
components/AddToCartForm.astro
components/AddToCartFormSync.astro
components/BuyNowForm.astro
components/WishlistForm.astro
components/VariantOptionGroups.astro
components/VariantSelector.astro
components/StockBadge.astro
components/LowStockNotice.astro
components/UnavailableNotice.astro
components/ProductStructuredData.astro
```

`ProductPurchase` is the form owner. It uses `createMikaPurchaseModel()` to
select the active sellable and price, derive hidden form fields, cap quantity by
availability, and coordinate grouped variant controls.

## 4. Render A Product Page

Host product pages stay host-owned. Mika only supplies the request-bound helper,
actions, and purchase components.

```astro
---
import { actions } from "astro:actions";
import { createMika } from "@bnomei/emdash-mika/astro";
import { api } from "../lib/mika-api";
import ProductPurchase from "../components/ProductPurchase.astro";
import ProductStructuredData from "../components/ProductStructuredData.astro";

export const prerender = false;

const Mika = createMika(Astro, { api });
const checkoutResult = Astro.getActionResult(actions.mika.checkout.start);
if (checkoutResult?.data?.ok && checkoutResult.data.data.redirectUrl) {
  return Astro.redirect(checkoutResult.data.data.redirectUrl);
}

const addResult = Astro.getActionResult(actions.mika.cart.add);
const wishlistResult = Astro.getActionResult(actions.mika.wishlist.add);
const formError =
  checkoutResult?.error?.message ??
  addResult?.error?.message ??
  wishlistResult?.error?.message ??
  (checkoutResult?.data?.ok === false ? checkoutResult.data.error.message : null) ??
  (addResult?.data?.ok === false ? addResult.data.error.message : null) ??
  (wishlistResult?.data?.ok === false ? wishlistResult.data.error.message : null);

const id = Astro.params["id"];
if (!id) return Astro.redirect("/404");

const sellablesResult = await Mika.catalog.sellables("products", id);
const sellables = sellablesResult.ok ? sellablesResult.data : [];
---

<ProductStructuredData
  sellables={sellables}
  product={{
    name: "Product title from the host entry",
    description: "Product description from the host entry",
    url: Astro.url,
  }}
/>

{formError && <p role="alert">{formError}</p>}
<ProductPurchase sellables={sellables} />
```

Replace the placeholder product fields with the host EmDash entry data. The
important shape is that product content and routing stay in the host project,
while Mika resolves sellables and form contracts for that content reference.

## 5. Add Cart, Wishlist, Checkout, Account, And Downloads

After the core product flow, copy these additional files when the storefront
needs the full customer path:

```txt
lib/account.ts
lib/cart.ts
components/CartLines.astro
components/CartSummary.astro
components/CouponForm.astro
components/CheckoutForm.astro
components/WishlistList.astro
components/MagicLinkForm.astro
components/AccountSignInPanel.astro
components/AccountOrders.astro
components/AccountSubscriptions.astro
components/AccountLicenses.astro
components/AccountDownloads.astro
pages/cart.astro
pages/wishlist.astro
pages/checkout/success.astro
pages/checkout/cancel.astro
pages/account.astro
pages/account/orders.astro
pages/account/subscriptions.astro
pages/account/licenses.astro
pages/account/downloads.astro
pages/account/magic-link.astro
pages/download/[token].astro
pages/api/mika-webhook/[provider].ts
```

The copied pages export `prerender = false` because Astro Actions, sessions,
and request-bound cart/account state need on-demand rendering.

The webhook endpoint is a host Astro endpoint. It forwards the raw request to
`Mika.webhook.receive` and requires a provider adapter that can verify and parse
the webhook.

## Boundaries

- Browser mutations use Astro Actions such as `actions.mika.cart.add`,
  `actions.mika.checkout.start`, and `actions.mika.wishlist.add`.
- Public plugin JSON routes are limited to catalog and stock reads.
- Cart, checkout, account, subscription, webhook, admin, export, and delete
  routes are not public browser JSON mutation routes.
- Checkout cancel pages are passive return surfaces. Mika releases expired stock
  reservations from scheduled maintenance, not because a customer visits cancel.
