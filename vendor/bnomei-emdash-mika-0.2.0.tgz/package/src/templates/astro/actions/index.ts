// mika-template-version: 0.2.0
/**
 * Astro Actions server registration for the storefront template.
 * Exposes Mika mutations under `server.mika` for form posts and client calls.
 */
import { createMikaActions } from "./mika";
import { createMikaStorefrontActions } from "@bnomei/emdash-mika/storefront-actions";
import { api, storefrontOptions } from "../lib/mika-api";

/** Registered Astro Actions map; `mika` holds commerce mutation handlers. */
export const server = {
  mika: createMikaActions({ api }),
  ...(storefrontOptions ? { mikaStorefront: createMikaStorefrontActions(storefrontOptions) } : {}),
};
