/** Package-owned endpoint: the integration supplies live server wiring through Vite. */
import type { APIRoute } from "astro";
import {
  handleMikaAccountExportHttp,
  validateMikaAccountExportHttpWiring,
} from "@bnomei/emdash-mika/astro";
// @ts-expect-error Virtual host module supplied by mikaAccountExportIntegration.
import * as wiring from "virtual:mika-account-export-wiring";

validateMikaAccountExportHttpWiring(wiring);

export const prerender = false;
export const ALL: APIRoute = (ctx) => handleMikaAccountExportHttp(ctx, wiring);
